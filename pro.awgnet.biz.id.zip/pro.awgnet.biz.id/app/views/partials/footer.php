<footer class="main-footer text-center py-2 mt-3">
    <strong>Billing ISP © <?= date('Y') ?></strong> — Dibuat dengan ❤️ oleh Budiono Siregar.
</footer>
